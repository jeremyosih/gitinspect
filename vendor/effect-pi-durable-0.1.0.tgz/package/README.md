# effect-pi-durable

An Effect v4 API for Pi Durable. Calling the agent and implementing its behavior both use Effect. Pi owns transactions, scheduling, task ownership, history, and recovery.

This package is not published to npm. Tested dependencies: Pi Durable / Pi AI / Chord **1.0.1**, Effect / Effect Browser Platform **4.0.0-rc.112**, Bun **1.4.2**. The contract is in [SPEC.md](SPEC.md). All examples from the Pi Durable article are adapted and typechecked in [ARTICLE_EXAMPLES.md](ARTICLE_EXAMPLES.md).

## Infrastructure through Layers

```ts
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Pi from "effect-pi-durable";
import { sqliteStorageLayer, nodeExecutionEnvLayer } from "effect-pi-durable/node";

const AgentLive = Pi.Harness.layer({
  extensions: [Pi.CodingTools],
  settings: {
    compaction: { reserveTokens: 16_384, backgroundTokens: 32_768 },
  },
}).pipe(
  Layer.provide(sqliteStorageLayer("./agent.sqlite")),
  Layer.provide(Pi.Models.fromPiAi(models)),
  Layer.provide(nodeExecutionEnvLayer()),
);

const program = Effect.gen(function* () {
  const harness = yield* Pi.Harness;
  const root = yield* harness.root({
    agent: {
      model: { provider: "openai", modelId: "your-model" },
      cwd: "/work/repo",
    },
  });
  const submission = yield* root.submit({
    type: "input",
    content: "Fix the failing tests",
    requestId: "fix-tests-42",
  });
  return yield* submission.answer;
});

await Effect.runPromise(program.pipe(Effect.provide(AgentLive)));
```

`Pi.Harness` is the Context service. Its Layer closes the harness when its scope ends. `Pi.Storage.memory`, `Pi.Storage.fromEffect(acquisition)`, `Pi.Storage.fromPi(storage)`, and `Pi.Storage.sqlite(database)` provide storage. Filesystem paths and Node execution environments belong to the `/node` entry point.

`submission.wait` returns Pi's durable receipt, including `unanswered`. `submission.answer` returns `{ entryId, text, entry, message, receipt }` for answered input or fails with `SubmissionUnanswered`. A passive write has a receipt but no assistant answer. Interrupting either wait cancels the waiter. Abort operations explicitly abort durable work.

Reopen the same storage and resubmit the same request ID to reuse the submission. `yield* harness.resume` explicitly enables scheduling; submitting or waiting also enables it according to Pi's rules.

## Pure declarations and Effect behavior

```ts
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Schema from "effect/Schema";

class SearchFailed extends Schema.TaggedError<SearchFailed>()("SearchFailed", {
  message: Schema.String,
}) {}

class IssueTracker extends Context.Service<
  IssueTracker,
  {
    readonly search: (query: string) => Effect.Effect<string, SearchFailed>;
  }
>()("app/IssueTracker") {}

const SearchIssues = Pi.Tool.make({
  name: "search_issues",
  description: "Find matching issues",
  parameters: Schema.Struct({ query: Schema.String }),
  success: Schema.String,
  failure: SearchFailed,
  replay: "safe",
  execute: Effect.fn("SearchIssues")(function* ({ query }, call) {
    const tracker = yield* IssueTracker;
    yield* call.output(`Looking up: ${query}`);
    return yield* tracker.search(query);
  }),
});

const Ops = Pi.Extension.make({ name: "ops", tools: [SearchIssues] });
const OpsAgentLive = Pi.Harness.layer({ extensions: [Ops] }).pipe(
  Layer.provide(IssueTrackerLive),
  Layer.provide(Pi.Storage.memory),
  Layer.provide(Pi.Models.fromPiAi(models)),
  Layer.provide(Pi.ExecutionEnv.none),
);
```

Making a declaration does not acquire dependencies or execute callbacks. The Harness Layer acquires its extensions. Alternatively, `Ops.layer` installs into `Pi.Registry`; provide `Pi.Registry.layer` and compose it before the Harness Layer. Both capture required services while the owning Layer is alive. Tools, tasks, sections, and hooks get a fresh invocation scope. Resources acquired by `ExecutionEnv.layer(resolve)` remain alive until that Layer closes, because Pi uses the resolved environment after the resolver returns and supplies no invocation cleanup boundary. Failed or interrupted environment resolutions release their acquired resources immediately.

`harness.root`, `harness.createConversation`, and `conversation.fork` accept Effect `init(tx, conversationId)` callbacks. Their errors and dependencies remain in the calling Effect's type, and the initializer runs inside Pi's creating transaction. `Harness.layer` also accepts an Effect `conversationCreated` hook for every creation path, including raw transaction creation; its declared errors become typed runtime errors with the original cause.

Tools decode parameters with Effect Schema, validate and encode success values, and encode declared failures into Pi's error results. Success defaults to model-visible text. An optional pure `toResult(value)` receives the validated decoded success value and returns Pi's complete `ToolExecutionResult`, including images, structured details, diagnostics, usage, and controls. A failure codec encodes one declared business failure. Compound Causes, defects, interruption, and runtime-boundary failures retain Pi's own error handling. Public runtime errors are `Schema.TaggedError` classes; `Pi.RuntimeError` is their Schema union. Native replay policy, execution mode, argument preparation, sampling, and output limits are supported. Pure argument preparation, task migrations, result rendering, and report callbacks remain synchronous because Pi invokes them synchronously; executable agent behavior returns Effects.

```ts
const Screenshot = Pi.Tool.make({
  name: "screenshot",
  description: "Capture the current screen",
  parameters: Schema.Struct({}),
  success: Schema.Struct({ data: Schema.String, mimeType: Schema.String }),
  execute: Effect.fn("Screenshot")(function* () {
    const screens = yield* Screens;
    return yield* screens.capture();
  }),
  toResult: ({ data, mimeType }) => ({
    content: [{ type: "image", data, mimeType }],
    details: { mimeType },
  }),
});
```

Public Effect operations produce named operation spans (`Effect.withSpan("Domain.operation")`). Synchronous per-chunk calls such as `call.output` are not traced. Each tool, task, section, hook and environment invocation starts a root span (`Tool.<name>`, `Task.<name>`, `Section.<key>`, `Hook.<name>`), because Pi invokes them outside the fiber that submitted the work. Configure tracing through the usual Effect tracer services.

`Pi.Section.make(key, render)`, `Pi.Hook.make(taskKind, handlers)`, `Pi.Section.wrap(key, wrapper)`, and `Pi.Tool.wrap(tool, wrapper)` declare Effect sections, hooks, and wrappers. Wrapping exposes Pi's complete `ToolExecutionResult`, preserving content, details, controls, and diagnostics. `Pi.Bash` is a typed wrapping target for the built-in bash tool. `Pi.Bash.make({ commandPrefix, prepare })` declares a configured bash tool whose preparation returns an Effect and can require application services:

```ts
const Bash = Pi.Bash.make({
  prepare: Effect.fn("Bash.prepare")(function* (execution, call) {
    const secrets = yield* Secrets;
    execution.env = yield* secrets.environment(call.conversationId);
  }),
});

const Shell = Pi.Extension.make({ name: "shell", tools: [Bash] });
```

`registry.subscribe(listener)` belongs to the current Effect Scope and detaches when that Scope closes. Observation acquisition is interruptible; cancelling acquisition cannot leave a late observer attached.

Tool selection accepts declarations: `yield* thread.configure({ tools: { remove: [SearchIssues] } })`. `yield* registry.install(nextExtension)` replaces the installed extension by name. Pi keeps existing invocations on their resolved code and resolves subsequent work from the published registry.

## Durable documents and owned conversations

```ts
const Todos = Pi.Document.make({
  kind: "app.todos",
  version: 1,
  scope: "conversation",
  history: "rewindable",
  fork: "asOf",
  schema: Schema.Struct({ items: Schema.Array(Schema.String) }),
  initial: () => ({ items: [] }),
});

// Inside a tool:
yield *
  call.commit((tx) =>
    Effect.gen(function* () {
      const draft = yield* tx.doc(Todos, call.conversationId);
      draft.items.push("Inspect staging");
    }),
  );

const child =
  yield *
  call.ownedConversation({
    key: "classifier",
    agent: { tools: [], instructions: "Classify the issue." },
  });
const submission =
  yield *
  child.submit({
    type: "input",
    content: issue,
    requestId: `classify:${call.taskId}`,
  });
const answer = yield * submission.answer;
```

Document schemas are explicit on their declarations. Draft validation runs lazily before commit and fails with `DocumentValidationError`, allowing Pi to roll back. Effect's readonly array schemas produce mutable transaction drafts, including nested arrays and structs. Mutable drafts belong inside transaction callbacks. `Pi.Document.family` preserves keyed family semantics.

`ownedConversation` finds or creates a task-owned conversation and persists its key in a task document in the same transaction. Replaying the same task reuses it. Stable request IDs remain necessary for external effects and child submissions.

## Custom durable tasks

```ts
const Payment = Pi.Task.make({
  name: "shop.payment",
  version: 1,
  input: Schema.Struct({ card: Schema.String }),
  checkpoint: Schema.Struct({ phase: Schema.Literal("charge") }),
  success: Schema.String,
  failure: PaymentDeclined,
  initial: () => ({ phase: "charge" as const }),
  phases: {
    charge: (task, runtime) =>
      Effect.gen(function* () {
        const bank = yield* Bank;
        const receipt = yield* bank.charge({
          card: task.input.card,
          idempotencyKey: `payment:${task.id}`,
        });
        yield* runtime.commit(() =>
          Effect.succeed({
            status: "terminal",
            outcome: { status: "completed", result: receipt },
          }),
        );
      }),
  },
  abort: (task, runtime) =>
    Effect.gen(function* () {
      const bank = yield* Bank;
      yield* bank.refund(`payment:${task.id}`);
      yield* runtime.commit(() =>
        Effect.succeed({
          status: "terminal",
          outcome: { status: "aborted" },
        }),
      );
    }),
});

const Jobs = Pi.Extension.make({ name: "shop", tasks: [Payment] });
// After installing Jobs:
const id =
  yield *
  root.commit((tx) => tx.createTask(Payment, { card }, { ownership: { kind: "conversation" } }));
const settled = yield * harness.waitForTask(id);
```

Phase and abort Effects keep their service requirements. Input, checkpoints, and completed results are schema validated. Declared phase failures become durable `failed` outcomes with encoded error details; defects become `faulted`. Native migrations, hooks, child ownership, and persisted waiting states remain available. Create children and commit their waiting checkpoint inside one `runtime.commit` callback. A fiber waiting in memory is not a durable wait.

## Browser compatibility and interop

The root API and portable entry points contain no Node APIs. [examples/browser.ts](examples/browser.ts) runs with Effect Browser Platform, a real Pi harness, schema tools/documents, memory storage, and watch Streams. Persistent browser storage and execution environments must implement Pi's contracts; Browser Platform alone does not supply Pi's SQLite database, filesystem, or shell. All records and documents must participate in the same atomic Storage commit.

Complete runtime handles expose Effects for Pi operations, scoped watches, `conversation.views`, task graph observation, document families, memos, compaction, forks, handoff/reset, and explicit aborts. Typed overload coverage is checked against upstream declarations in [test/api-coverage.types.ts](test/api-coverage.types.ts).

`Native` and `.raw` are explicit interop boundaries. Lower-level Effect registration adapters (`tool`, `task`, `defineTool`, `defineTask`, `promptSection`, `hooks`) remain available for native result shapes. `Harness.open` is a scoped lower-level acquisition; `Harness.layer` is the application composition API. Orchestration and external agent SDKs are outside this package's scope.

## Development

```sh
bun install
bun run check
bun run build
bun run examples/agent.ts
bun run example:browser
```

Examples use Pi's faux provider and require no credentials. Oxfmt, Oxlint, and the vendored dmmulroy/anti-slop plugin run with strict TypeScript. Tooling follows Executor v2. `bun run generate` regenerates explicit upstream bindings; lint autofix and formatting must reach a stable second pass. Nothing is published or pushed by these commands.

The [Effect API review](EFFECT_API_REVIEW.md) records the pinned Kit Langton skill and OpenCode beta patterns used here.

## Contract verification

`bun run check` runs formatting, strict anti-slop lint, TypeScript contracts, and the real integration suite. `bun test test/upstream` runs the upstream behavioral ports through this library; no test calls the native Pi SDK runtime directly.

The [coverage ledger](test/upstream/COVERAGE.md) accounts for all 702 test declarations in the pinned 42-file Pi Durable source suite. Parameterized tests and storage conformance registrations expand at runtime. Private cache mutation, allocation metrics, native Context injection, and other unavailable internals remain explicit exclusions or partial replacements. This is public API contract coverage, not a claim that every upstream private unit test can run through the wrapper. Source provenance, adaptations, and runtime versions are recorded in [UPSTREAM.md](test/upstream/UPSTREAM.md).
