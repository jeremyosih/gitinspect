# Effect Pi Durable specification

## Scope

Implement a faithful, idiomatic Effect v4 wrapper of Pi Durable. Pi alone owns the agent loop, task scheduling, ownership, checkpoints, migrations, transcript history, transactions, publication, and recovery. No application orchestration, external-agent backend selection, or replacement agent loop belongs in this repository.

The package is named `effect-pi-durable`. It is private; publishing is deferred. Local commits are authorized. Tested dependencies are Pi Durable, Pi AI, and Chord 1.0.1, and Effect / Effect Browser Platform 4.0.0-rc.112. Compatibility refers to this pinned upstream release, not arbitrary future Pi versions.

## Effect-native application API

Keep Pi's concepts while replacing application infrastructure with Context services and Layers. `Harness` is a yieldable service; `Harness.layer(options)` acquires declarations, consumes Storage, Models, and ExecutionEnv services, and scopes the harness. Models.fromPiAi adapts a supplied Pi AI registry. Storage layers support memory, compatible native storage, Effect acquisition, and portable SQLite databases. Node path-based storage and execution layers stay under `/node`.

Tool.make, Task.make, Extension.make, Section.make, Hook.make, Tool.wrap, Section.wrap, and Document.make/family are pure declarations. Making one acquires nothing. Extension layers install into the Effect Registry service, or the Harness Layer acquires its listed declarations. Dependencies from tools, tasks, hooks, sections, and wrappers propagate to the owning Layer and are captured there. Registry.install/uninstall are Effects; registry replacement keeps Pi publication semantics.

Tool.make accepts Effect Schema parameters, success, and an optional declared failure codec. Execute returns a domain success value through Effect; encoded string results remain text and other JSON values are serialized as text. Optional pure toResult receives the validated decoded success and renders the full native ToolExecutionResult; schema validation runs before rendering. Public Effect operations carry named operation spans. Declared failures encode as Pi tool error results. Tool.wrap exposes the native complete result to preserve controls, diagnostics, and details. Native tool options and built-in coding registrations remain supported.

Task.make declares input, checkpoint, success, optional failure schemas, explicit phases, initial, abort, migrations, and hooks. Its token can create tasks before execution resolves the installed registration. Input/checkpoints are validated at creation and invocation; committed checkpoints and completed results are validated before durable commit. Declared unhandled phase failures commit failed outcomes with encoded details. Defects remain faulted. Native persisted waiting and task ownership are retained. Explicit failed outcomes retain Pi's structured error shape; the adapter does not accept arbitrary unencoded error objects as native outcomes.

Submission.wait and Harness.resume are Effect properties. Submission.answer is an optional convenience: answered input returns the validated assistant entry, message, flattened text, entryId, and full receipt. Unanswered input or passive writes fail with SubmissionUnanswered. Missing or inconsistent assistant entries fail with PiError. Interrupting answer cancels the waiter, not durable work.

ToolApi.ownedConversation atomically looks up or creates a conversation keyed to the current tool task, configures it, and stores its ID in a task-owned document within the same transaction. Keys are independent; replaying the same task after reopening storage reuses the ID. No memory cache substitutes for this durable mapping. The child is owned by the current task. Stable external idempotency keys and submission request IDs remain application responsibilities.

Root, createConversation, and fork accept Effect initializer callbacks. They capture caller services, propagate declared errors through their Effect signatures, validate touched document drafts before commit, and preserve atomic creation/rollback. The Harness Layer supports Effect conversationCreated hooks with dependency propagation and runtime error normalization.

Agent tool selections accept declaration identities and persist their names through Pi configure. Low-level native-shaped Effect adapters and Native/.raw remain explicit interop paths. Application examples use the service and declaration API.

## API fidelity

Retain every root runtime export, built-in document, entry, task kind, policy, identifier, definition helper, and registry operation. Pure registry, extension, document, entry, and wrapper helpers retain Pi behavior. Executable registrations are native Pi values, so registries and built-in coding tools interoperate directly. `Native` exposes unmodified upstream exports for interoperability.

Preserve every member of Harness, Session, Conversation, ConversationHandle, Submission, Tx, TaskRuntime, ToolExecutionApi, HookApi, DocumentReader, DocumentObserver, Storage, WatchHandle, and AgentEventStream. Preserve generic document, family, entry, task result, memo, and SQL overloads. Transactions expose direct methods; a generic escape hatch is not the implementation of public coverage.

Promise-returning operations become lazy Effects. Chord Context arguments are supplied from the Effect fiber's AbortSignal rather than required from the caller. Synchronous side-effecting runtime operations such as resume, output, and report become Effects; pure metadata remains synchronous. Watch `closed` is an Effect property, matching the native Promise property's role. Scope is required for acquired watches, subscriptions, sessions, harnesses, attached states, and line readers. Preserve `undefined` for absent handles and documents, `null` for retired observed document values, and Pi's exact submission/task outcomes.

Keep the upstream entry-point families: root, env, env/node, tools, storage/memory, storage/jsonl, storage/jsonl/node, storage/sqlite, storage/sqlite/node, and testing. Add the consolidated node convenience entry point. Node dependencies must never enter the root/portable import graph.

## Ownership and lifecycle

`Harness.open` / `open` and `createSession` acquire scoped wrappers. Harness and Session close seals admission, settles admitted work, and closes owned storage. Closing preserves pending durable work; it is not an abort. Cleanup uses a non-cancelling context. Failed harness acquisition closes supplied storage. `Harness` (also aliased as `Service`) and Harness.layer provide the service-first API. The lower-level `layer(storageEffect, options)` remains an interop acquisition. Storage Layers scope storage resources; Harness closure finishes invocations before dependency Layers release their services.

Accept either a complete native Pi Storage or the wrapper's Storage handle. Storage must retain Pi's atomic commit contract over all records and documents. A separate document database cannot bypass that commit boundary. Memory, portable JSONL, portable SQLite, and Node storage factories return compatible handles. Unscoped storage/database factories transfer ownership to their eventual owner or must be explicitly closed by the caller.

Each executable callback gets a fresh invocation Scope. Capture Effect dependencies when acquiring its registration; those dependencies must outlive all invocations. Release scoped resources and fibers at invocation completion. Do not serialize executable functions or Effect service contexts. Reconstruct them when reopening durable work.

## Cancellation and errors

Connect local operation interruption to upstream Chord cancellation. Cancelling a wait cancels that waiter; it must not implicitly abort a submission, conversation, or durable task. Abort operations remain explicit. Preserve upstream admission and commit settlement semantics.

Use tagged ConversationBusy, ReadAfterWrite, StorageRejected, PiError, FileError, ExecutionError, and DocumentValidationError errors. Preserve native causes, operation names, conversation IDs, filesystem codes/paths, and execution codes/spill paths. Do not classify errors by parsing messages.

Effect transaction and SQL transaction callbacks retain their expected error type, defects, and interruption across native Promise boundaries through an internal Cause carrier. Rollback remains upstream's responsibility; never claim rollback when native storage or SQL reports an uncertain settlement.

Tool/task expected failures follow Pi's throw/fault behavior by default. Optional explicit failure codecs on Schema conveniences can encode expected failures as model-visible tool errors or durable failed task outcomes. Encode only a single declared business failure; a compound Cause cannot be represented by a single failure codec and must reach Pi intact. Never encode defects, interruption, or runtime-boundary errors as business failures. Public adapter errors use Schema.TaggedError and RuntimeError exports their Schema union alongside the error type.

Portable environment methods lift Pi's Result values into Effect success/failure channels. Filesystem and execution error codes are preserved. Line readers are scoped. ExecutionEnv resolver resources belong to child scopes of the installing Layer and remain alive until that Layer closes; failed or interrupted resolutions close immediately. Other executable callbacks use invocation scopes. Shell output callbacks keep Pi's synchronous contract.

## Authoring

`defineTool` accepts all native tool options, including TypeBox parameters, constrained sampling, argument preparation, replay policy, execution mode, and output limits; execute receives an Effect ToolExecutionApi. `tool` additionally supports Effect Schema input decoding and an optional failure codec. Schema input must be representable as model-facing JSON Schema.

`defineTask` / `task` preserve names, versions, pure initial checkpoints, exhaustive phase narrowing, abort handlers, migrations, and custom hooks. Phase and abort handlers return Effect and receive the complete TaskRuntime. Progress, waiting, completion, abort drainage, and recovery retain Pi semantics. Returning without required progress is governed by Pi.

`section` / `promptSection` support Effect renderers returning string or undefined and provide Effect document/environment access. `hook` / `hooks` adapt callback arguments, document reads, and memos while supplying cancellation. `initializer`, `conversationCreated`, and `environment` adapt the corresponding native options. Pure `wrapTool`, `wrapSection`, and `defineExtension` remain native-compatible registration composition.

Replacing registry definitions remains explicit. Existing invocations keep their resolved definitions; subsequent phases use Pi's refreshed registry snapshots. Ordinary Effect fibers are process-local and never become durable tasks automatically.

## Transactions and documents

Tx preserves all native reads, scans, history, creation, entries, submissions, task transitions, document/family access, and retirement overloads. The Effect commit callback executes on Pi's mutation line. Agent configuration, document changes, transcript writes, and task creation can share one atomic commit. Preserve the prohibition on table reads after table writes.

Native defineDoc / defineDocFamily retain versions, migrations, document semantics, history, copies, and fork behavior. Optional `document` / `documentFamily` conveniences validate initial values, migrations, and final drafts using Effect Schema. Readonly Effect JSON schemas are accepted; native tokens expose Pi's mutable Draft projection, while the original schema remains explicit. Schemas are explicit SchemaDocument declarations; touched drafts are tracked directly and validated lazily through Effect before commit. Validation failures stay in the typed error channel; there are no hidden symbols or Proxy interception. Validation applies to wrapper transactions and does not intercept writes made through native handles.

Document-family reads and watches require a key, never a creation seed; only creating Tx access takes the seed. Reads and watch acquisition do not create missing documents. Attached states retain their native synchronous value/subscribe/dispose interface and receive automatic scoped disposal.

## Observation

Expose native-shaped scoped watch handles with value/snapshot, start, stop, and closed, plus bounded Effect Streams. `Watch.frames` carries the value and exact delta operations; `Watch.values` carries values. AgentEventStream.stream carries committed event batches. Conversation.views and Harness.events are conveniences.

Streams include the attachment snapshot. Scope closure stops the handle. Preserve upstream bounded pending frames and snapshot coalescing; do not promise historical replay or allocate an unbounded queue. Normal closure ends a Stream; listener failure fails it. Do not detach background listener fibers from invocation lifetime.

## Browser contract

The root and portable SQLite/JSONL cores use no Node APIs. They can run under Effect BrowserRuntime when models, storage adapters, and execution capabilities support that runtime. Browser Platform does not automatically provide a Pi-compatible persistent store or shell. Memory storage works in-browser but does not survive reload. SQLite needs a browser database facade; JSONL needs a browser-capable Pi filesystem. No persistent browser adapter is shipped in this implementation.

Closing a page stops local execution. Persistence can allow later recovery; it cannot make a closed page keep running. Node filesystem, shell, and node:sqlite facilities belong exclusively in Node entry points.

## Verification and completion

Compile-time checks compare every core interface member and root runtime export against the pinned upstream package, including portable environment and SQLite database interfaces. Generic assignments verify document/family reads, drafts, and memo results. These checks prove surface coverage, not every possible behavioral trace.

Integration tests run actual Pi harnesses and storage implementations with a deterministic faux model: scope cleanup, acquisition failure, rollback, typed failures and defects, interruption, submission deduplication, hooks/sections, tool execution, service capture, invocation finalization, task completion/failure/migration/recovery, document validation/families, watch snapshots/closure, environment errors, and SQL rollback. JSONL and SQLite reopen must recover persisted state. No credentials or paid model requests are needed.

Source, tests, and examples typecheck. Build emits ESM and declarations. Both built-output imports and a runnable agent example work. A browser bundle is executed in the actual collaborative browser using BrowserRuntime, a real memory-backed Pi harness, an Effect tool, a committed document, a receipt, and a watch snapshot, with no Node process global.

The upstream contract suite records all 702 declarations from 42 pinned source files in `test/upstream/manifest.json`. Reviewed per-case mappings distinguish direct ports, public behavioral adaptations, compile contracts, partial replacements, and inaccessible private internals. Parameterization and shared storage conformance produce additional runtime tests. The coverage ledger records exact limitations; importing a private SDK helper or weakening an assertion does not count as a complete port.

Current verified result: **869 tests pass, one platform-dependent test is skipped, and none fail** (4,872 assertions across 55 files). Formatting, strict anti-slop lint, TypeScript contracts, ESM/declaration build, the local agent example, and the actual browser smoke pass. Live provider authentication/network behavior and persistent browser storage are not validated.

## Development tooling

Follow the Oxfmt/Oxlint/strict TypeScript workflow inspected on Executor v2. Enable every generic and Effect rule from dmmulroy/anti-slop at the installed revision, with matching pinned Oxlint/plugin dependencies and exact provenance. Use a self-contained vendored plugin and local installer skill. `check` combines formatting, lint with warnings denied, typechecking and real Pi integration tests. Do not import Executor's application-specific deployment infrastructure or remove this library's integration coverage.

The public API uses direct Effect operations and `Harness.Service` / `Harness.layer`; reflective generic `.methods` and public `.call` adapters are not part of the contract. Native interoperation remains explicit and isolated. Generate single-signature operations as ordinary typed calls. Generic overload implementations may erase their signature only at the documented native boundary, with a checked invariant and no Reflect dispatch. Error classification uses Effect Match; the wrapper error guard is an Effect Schema union predicate.
